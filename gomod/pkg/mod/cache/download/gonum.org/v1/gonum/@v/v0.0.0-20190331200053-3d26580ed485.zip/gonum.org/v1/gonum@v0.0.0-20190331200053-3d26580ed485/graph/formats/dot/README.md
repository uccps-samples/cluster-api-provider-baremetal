# formats/dot

## License

The source code and any original content of the formats/dot directory is released under [Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/).

The source code is also licensed under the gonum license, and users are free to choose the license which suits their needs.

Please see gonum.org/v1/gonum for general license information, contributors, authors, etc on the Gonum suite of packages.
