## count

[Alpha] Count Resources Config from a local directory.

### Synopsis

[Alpha] Count Resources Config from a local directory.

  DIR:
    Path to local directory.

### Examples

    # print Resource counts from a directory
    kustomize cfg count my-dir/