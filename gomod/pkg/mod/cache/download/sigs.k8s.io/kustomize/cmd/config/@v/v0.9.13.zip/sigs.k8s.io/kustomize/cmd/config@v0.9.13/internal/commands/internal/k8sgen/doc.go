// Copyright 2020 The Kubernetes Authors.
// SPDX-License-Identifier: Apache-2.0

// All code below this directory is generated.
// See {repo}/cmd/k8scopy/main.go for more info.
//go:generate k8scopy k8scopy.yaml internal/commands
package k8sgen
