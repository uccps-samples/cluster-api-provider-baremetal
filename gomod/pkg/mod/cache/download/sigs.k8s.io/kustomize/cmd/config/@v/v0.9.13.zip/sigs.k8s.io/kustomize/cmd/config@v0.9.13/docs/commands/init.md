## init

[Alpha] Initialize a directory with a Krmfile.

### Synopsis

[Alpha]  Initialize a directory with a Krmfile.

  DIR:
    Path to local directory.

### Examples

    # create a Krmfile in the local directory
    kustomize cfg init

    # create a Krmfile in my-dir/
    kustomize cfg init my-dir/
