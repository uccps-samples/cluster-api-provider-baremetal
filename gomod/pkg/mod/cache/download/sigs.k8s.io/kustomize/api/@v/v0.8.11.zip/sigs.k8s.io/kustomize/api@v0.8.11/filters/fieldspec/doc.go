// Copyright 2020 The Kubernetes Authors.
// SPDX-License-Identifier: Apache-2.0

// Package fieldspec contains a yaml.Filter to modify a resource
// that matches the FieldSpec.
package fieldspec
