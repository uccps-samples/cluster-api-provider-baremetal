// Package nameref contains a kio.Filter implementation of the kustomize
// name reference transformer.
package nameref
