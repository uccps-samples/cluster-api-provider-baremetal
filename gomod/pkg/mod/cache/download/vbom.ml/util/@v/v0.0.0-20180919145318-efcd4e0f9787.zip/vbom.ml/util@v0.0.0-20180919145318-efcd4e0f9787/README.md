## util [![GoDoc](https://godoc.org/vbom.ml/util?status.svg)](https://godoc.org/vbom.ml/util)

    import "vbom.ml/util"

Go utility packages.
