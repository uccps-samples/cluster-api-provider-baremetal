#define K 278

enum {
	c = 42 - 24,
	d = 314 + K,
} foo;

