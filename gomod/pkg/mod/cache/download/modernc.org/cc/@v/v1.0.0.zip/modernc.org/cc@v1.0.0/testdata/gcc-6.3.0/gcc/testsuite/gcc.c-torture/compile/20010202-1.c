int foo (int n, char m[1][n]);

int foo (int n, char m[1][n])
{
}

