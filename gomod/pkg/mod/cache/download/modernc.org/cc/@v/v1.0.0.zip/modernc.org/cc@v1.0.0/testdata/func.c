void f(char *) {
	f(__func__);
}
