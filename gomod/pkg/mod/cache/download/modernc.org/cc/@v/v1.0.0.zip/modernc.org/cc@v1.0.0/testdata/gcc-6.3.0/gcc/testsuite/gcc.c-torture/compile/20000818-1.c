void
foo (long double x)
{
  struct {long double t;} y = {x};
}

