extern char foo[], bar[];
void f (void) { memcpy (foo, bar, 7); }
