char list[250][64];

int f(int idx) { return (strlen(list[idx])); }

