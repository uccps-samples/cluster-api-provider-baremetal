// Invalid anonymous field should raise an error but not panic.

struct {
	_Bool;
};
