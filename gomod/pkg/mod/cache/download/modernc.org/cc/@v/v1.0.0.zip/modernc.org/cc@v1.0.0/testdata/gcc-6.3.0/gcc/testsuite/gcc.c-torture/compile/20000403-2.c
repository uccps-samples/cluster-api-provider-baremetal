void   
foo ()
{
 long long tmp;
 (( tmp ) = (long long)(  tmp ) >> (  32 )) ;
}
