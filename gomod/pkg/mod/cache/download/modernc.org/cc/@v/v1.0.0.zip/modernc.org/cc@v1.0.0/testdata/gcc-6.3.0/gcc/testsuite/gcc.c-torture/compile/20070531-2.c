int f(void)
{
  int *a = 0;
  for(a = 0; a < (int*)32767;a++)
   ;
}
