void foo(void)
{
  char c;

  for (c = -75; c <= 75; c++)
    ;
}
