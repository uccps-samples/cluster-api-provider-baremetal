unsigned long long
f (__builtin_va_list  ap)
{
  return __builtin_va_arg (ap, unsigned long long);
}
