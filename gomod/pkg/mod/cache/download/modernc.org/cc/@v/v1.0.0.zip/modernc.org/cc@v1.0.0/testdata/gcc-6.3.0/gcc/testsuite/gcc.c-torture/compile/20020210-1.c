/* PR c/5615 */
void f(int a, struct {int b[a];} c) {}
