package nested

import (
	_ "k8s.io/gengo/examples/import-boss/tests/rules/c"
)
