# Temp

This package provides an interface to create temporary directories. It also
provides a [FakeDir](temp/temptest) implementation to replace in tests.
