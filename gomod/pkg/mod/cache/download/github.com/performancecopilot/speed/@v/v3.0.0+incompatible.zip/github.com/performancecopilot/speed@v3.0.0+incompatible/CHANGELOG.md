
v3.0.0 / 2017-10-30
==================

  * metrics: add support for multidimensional composite metrics (#50)
  * speed: remove logging from library (#49) (**BREAKING**)
  * add mmvdump tests (#48)

v2.0.0 / 2017-04-05
===================

  * examples: use log.Fatal instead of panic in all examples (#45)
  * examples: add example which exposes Go runtime metrics (#44)
  * Replace logrus with zap (#43)
  * Port Speed to Windows (#41)

v1.0.0 / 2016-10-28
===================
