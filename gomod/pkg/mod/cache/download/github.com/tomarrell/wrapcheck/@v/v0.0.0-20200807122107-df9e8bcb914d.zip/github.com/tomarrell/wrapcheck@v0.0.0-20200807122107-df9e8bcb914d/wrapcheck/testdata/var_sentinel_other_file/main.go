package main

func main() {
	do()
}

func do() error {
	return ErrorFailed
}
