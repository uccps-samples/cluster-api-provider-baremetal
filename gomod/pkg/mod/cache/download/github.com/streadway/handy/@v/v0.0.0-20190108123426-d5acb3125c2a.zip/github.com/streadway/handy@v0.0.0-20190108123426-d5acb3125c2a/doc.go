/*
Package handy organizes some useful http server handler filters or handlers for reuse.
*/
package documentation
