/*
Package statsd collects and reports telemetry from http handlers.
*/
package statsd
