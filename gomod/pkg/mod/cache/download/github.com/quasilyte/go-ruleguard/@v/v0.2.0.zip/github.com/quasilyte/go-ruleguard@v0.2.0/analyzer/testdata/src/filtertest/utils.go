package filtertest

func typeTest(args ...interface{}) {}
func pureTest(args ...interface{}) {}
func textTest(args ...interface{}) {}

func random() int {
	return 42
}
