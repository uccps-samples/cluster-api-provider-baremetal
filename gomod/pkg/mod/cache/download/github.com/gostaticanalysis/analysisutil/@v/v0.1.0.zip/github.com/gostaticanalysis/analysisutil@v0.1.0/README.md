# analysisutil

[![godoc.org][godoc-badge]][godoc]

Utilities for x/tools/go/analysis package.

<!-- links -->
[godoc]: https://godoc.org/github.com/gostaticanalysis/analysisutil
[godoc-badge]: https://img.shields.io/badge/godoc-reference-4F73B3.svg?style=flat-square&label=%20godoc.org

