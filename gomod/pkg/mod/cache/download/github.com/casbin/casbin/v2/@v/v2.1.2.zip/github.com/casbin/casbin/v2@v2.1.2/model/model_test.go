package model

import (
	"testing"
)

func TestModel(t *testing.T) {
	//No tests yet
}
