// Package examples demonstrates possible implementation of some
// random value generators.
package examples
