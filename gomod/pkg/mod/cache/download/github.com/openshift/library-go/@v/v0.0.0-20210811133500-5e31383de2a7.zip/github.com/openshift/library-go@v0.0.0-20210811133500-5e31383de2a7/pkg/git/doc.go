// Package git allows working with Git repositories
package git
