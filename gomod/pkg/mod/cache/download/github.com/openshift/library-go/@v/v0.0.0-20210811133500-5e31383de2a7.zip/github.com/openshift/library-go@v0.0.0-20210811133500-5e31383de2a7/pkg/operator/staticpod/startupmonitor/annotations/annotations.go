package annotations

const (
	FallbackForRevision = "startup-monitor.static-pods.openshift.io/fallback-for-revision"
	FallbackReason      = "startup-monitor.static-pods.openshift.io/fallback-reason"
	FallbackMessage     = "startup-monitor.static-pods.openshift.io/fallback-message"
)
