#!/bin/sh

golint -set_exit_status "${@}"
