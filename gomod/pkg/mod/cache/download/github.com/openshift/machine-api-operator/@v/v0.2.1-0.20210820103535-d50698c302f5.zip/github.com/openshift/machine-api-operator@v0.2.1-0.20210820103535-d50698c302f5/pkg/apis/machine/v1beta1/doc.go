// Package v1alpha1 contains API Schema definitions for the healthchecking v1beta1 API group
// +k8s:deepcopy-gen=package,register
// +groupName=machine.openshift.io
package v1beta1
