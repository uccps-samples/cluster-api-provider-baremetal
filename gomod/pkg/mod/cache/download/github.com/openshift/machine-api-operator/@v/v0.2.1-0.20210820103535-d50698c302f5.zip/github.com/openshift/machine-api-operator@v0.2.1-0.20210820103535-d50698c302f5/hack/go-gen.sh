#!/bin/sh

go generate ./pkg/apis/...

