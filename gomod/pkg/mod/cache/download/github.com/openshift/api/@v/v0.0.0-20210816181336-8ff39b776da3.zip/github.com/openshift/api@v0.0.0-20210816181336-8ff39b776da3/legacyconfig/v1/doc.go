// +k8s:deepcopy-gen=package,register
// +k8s:defaulter-gen=TypeMeta
// +k8s:openapi-gen=true

// +groupName=legacy.config.openshift.io
// Package v1 is deprecated and exists to ease a transition to current APIs
package v1
