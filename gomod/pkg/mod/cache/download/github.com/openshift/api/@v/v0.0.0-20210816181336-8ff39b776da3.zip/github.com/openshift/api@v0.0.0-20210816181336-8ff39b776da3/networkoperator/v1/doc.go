// Package v1 contains API Schema definitions for the network v1 API group
// +k8s:deepcopy-gen=package,register
// +groupName=network.operator.openshift.io
// +kubebuilder:validation:Optional
package v1
