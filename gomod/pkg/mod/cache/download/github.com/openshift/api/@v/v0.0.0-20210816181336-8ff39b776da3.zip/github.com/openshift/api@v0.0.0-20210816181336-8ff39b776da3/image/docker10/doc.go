// +k8s:deepcopy-gen=package,register

// Package docker10 is the docker10 version of the API.
package docker10
