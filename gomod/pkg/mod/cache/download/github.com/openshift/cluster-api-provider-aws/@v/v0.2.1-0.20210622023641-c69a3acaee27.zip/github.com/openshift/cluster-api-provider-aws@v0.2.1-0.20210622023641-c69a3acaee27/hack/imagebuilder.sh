#!/bin/sh
cd /tmp
go get -u github.com/openshift/imagebuilder/cmd/imagebuilder
cd -
