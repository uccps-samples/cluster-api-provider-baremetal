#!/bin/bash -x

oc delete baremetalhost -l metal3demo
