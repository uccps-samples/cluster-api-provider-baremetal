#!/bin/bash

sudo chown -R $USER bin \
    chown $USER .git/index
