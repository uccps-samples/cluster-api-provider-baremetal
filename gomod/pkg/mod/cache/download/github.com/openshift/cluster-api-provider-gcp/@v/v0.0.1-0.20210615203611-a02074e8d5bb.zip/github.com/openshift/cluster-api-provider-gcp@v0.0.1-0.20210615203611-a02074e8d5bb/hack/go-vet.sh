#!/bin/sh

go vet "${@}"

