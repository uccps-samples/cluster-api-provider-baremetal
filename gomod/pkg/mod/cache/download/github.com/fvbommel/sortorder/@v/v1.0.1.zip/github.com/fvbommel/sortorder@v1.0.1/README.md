# sortorder [![PkgGoDev](https://pkg.go.dev/badge/github.com/fvbommel/sortorder)](https://pkg.go.dev/github.com/fvbommel/sortorder)

    import "github.com/fvbommel/sortorder"

Sort orders and comparison functions.
