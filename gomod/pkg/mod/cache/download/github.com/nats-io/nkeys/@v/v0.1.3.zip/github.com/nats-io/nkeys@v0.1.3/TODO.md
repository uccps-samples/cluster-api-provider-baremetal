
# General

- [ ] Child key derivation
- [ ] Hardware support, e.g. YubiHSM
