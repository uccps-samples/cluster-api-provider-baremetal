# Maintainers

Maintainership is on a per project basis.

### Core-maintainers
  - Derek Collison <derek@nats.io> [@derekcollison](https://github.com/derekcollison)
  - Ivan Kozlovic <ivan@nats.io> [@kozlovic](https://github.com/kozlovic)
  
### Maintainers
  - Waldemar Quevedo <wally@nats.io> [@wallyqs](https://github.com/wallyqs)
  - Oleg Shaldybin <olegsh@google.com> [@olegshaldibin](https://github.com/olegshaldibin)