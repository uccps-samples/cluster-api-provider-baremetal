package checker_test

func noWarnings() {
	var b []byte
	var s string

	copy(b, s)
}
