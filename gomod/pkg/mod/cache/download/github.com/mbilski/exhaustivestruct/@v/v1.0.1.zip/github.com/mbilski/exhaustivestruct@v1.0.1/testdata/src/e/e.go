package e

type External struct {
	A string
	B string
}
