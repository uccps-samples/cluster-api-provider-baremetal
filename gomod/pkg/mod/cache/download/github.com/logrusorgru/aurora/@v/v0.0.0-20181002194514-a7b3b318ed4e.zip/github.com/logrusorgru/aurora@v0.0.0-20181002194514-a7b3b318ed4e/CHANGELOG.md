Changes
=======

---

14:25:49
Friday, August 18, 2017

- LICENSE.md changed to LICENSE
- fix email in README.md
- add "no warranty" to README.md
- set proper copyright date

---

16:59:28
Tuesday, November 8, 2016

- Rid out off sync.Pool
- Little optimisations (very little)
- Improved benchmarks

---
