package dst

//go:generate go get github.com/dave/rebecca/cmd/becca
//go:generate becca -package=github.com/dave/dst
