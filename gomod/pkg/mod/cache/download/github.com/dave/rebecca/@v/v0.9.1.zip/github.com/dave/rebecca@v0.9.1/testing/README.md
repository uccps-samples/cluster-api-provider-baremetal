# Test

Doc:
Foo bar

Code:
```go
{
	// foo
	fmt.Println("a")
}
```

Output:
```go
a
```

Full:
```go
// foo
fmt.Println("a")
// Output:
// a
```