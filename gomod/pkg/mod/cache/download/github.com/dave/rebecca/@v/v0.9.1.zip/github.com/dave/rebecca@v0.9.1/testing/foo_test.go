package testing

import "fmt"

func ExampleFoo() {
	// foo
	fmt.Println("a")
	// Output:
	// a
}
