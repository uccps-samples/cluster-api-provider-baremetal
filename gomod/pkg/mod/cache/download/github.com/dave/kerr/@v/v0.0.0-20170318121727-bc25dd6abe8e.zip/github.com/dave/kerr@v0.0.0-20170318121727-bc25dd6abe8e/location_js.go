// +build js

package kerr

// Error returns a string of the error
func formatLocation(e Struct) string {
	return ""
}
