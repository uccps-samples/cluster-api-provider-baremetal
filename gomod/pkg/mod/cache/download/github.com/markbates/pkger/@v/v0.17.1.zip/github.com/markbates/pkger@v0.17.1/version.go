package pkger

// Version of pkger
var Version = "development"
