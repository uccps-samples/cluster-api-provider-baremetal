package stdos
