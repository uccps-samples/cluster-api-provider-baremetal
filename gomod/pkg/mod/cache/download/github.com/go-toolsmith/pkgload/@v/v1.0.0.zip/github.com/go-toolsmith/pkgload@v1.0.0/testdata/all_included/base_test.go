package allincluded

import "testing"

func Test(t *testing.T) {}
