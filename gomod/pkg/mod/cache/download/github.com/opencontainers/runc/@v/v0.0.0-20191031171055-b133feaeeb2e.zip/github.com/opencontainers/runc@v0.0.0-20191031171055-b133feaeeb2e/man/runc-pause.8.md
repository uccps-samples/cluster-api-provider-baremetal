% runc-pause "8"

# NAME
   runc pause - pause suspends all processes inside the container

# SYNOPSIS
   runc pause `<container-id>`

Where "`<container-id>`" is the name for the instance of the container to be
paused. 

# DESCRIPTION
   The pause command suspends all processes in the instance of the container.
Use runc list to identify instances of containers and their current status.
