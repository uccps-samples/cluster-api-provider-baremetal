package testdata

import (
	"testing"
)

func TestSubtests(t *testing.T) {
	t.Parallel()

	t.Run("", func(t *testing.T) {
	})
}
