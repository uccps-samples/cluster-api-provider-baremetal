module.exports = {
  configPath: `src/config`,
  docsPath: `src/docs`,
  githubUrl: `https://github.com/golangci/golangci-lint`,
  baseDir: `docs`,
};
