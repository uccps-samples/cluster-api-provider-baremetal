#!/bin/bash -e

rm -rf build
rm -rf output
rm -rf dist
