package main

import "github.com/pact-foundation/pact-go/command"

func main() {
	command.Execute()
}
