# LightStep OpenCensus Exporter

[![GoDoc](https://godoc.org/github.com/lightstep/lightstep-tracer-go/lightstepoc?status.svg)](https://godoc.org/github.com/lightstep/lightstep-tracer-go/lightstepoc)

**This exporter is currently experimental. Breaking changes may occur between any version.**

For a full example, take a look [here](../examples/opencensus/main.go).

## Installation

```
go get "github.com/lightstep/lightstep-tracer-go/lightstepoc"
```
