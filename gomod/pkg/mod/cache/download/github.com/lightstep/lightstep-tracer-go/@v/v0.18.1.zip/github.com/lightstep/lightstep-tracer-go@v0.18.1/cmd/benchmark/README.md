# Benchmark

Benchmark client for lightstep-tracer-go, see http://github.com/lightstep/lightstep-benchmarks
