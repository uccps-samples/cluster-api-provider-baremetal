# sendspan

A simple program that sends a single span.

```sh
go run main.go -access_token=<your-access-token> -collector_host=<your-collector-host> -collector_port=<your-collector-port> -secure=<true/false> -transport=<grpc/http> -operation_name=<test-operation-name>
```
