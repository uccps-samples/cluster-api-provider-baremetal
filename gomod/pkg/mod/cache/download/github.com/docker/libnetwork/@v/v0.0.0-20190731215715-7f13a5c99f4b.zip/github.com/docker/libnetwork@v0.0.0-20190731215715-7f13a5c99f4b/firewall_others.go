// +build !linux

package libnetwork

func (c *controller) arrangeUserFilterRule() {
}
