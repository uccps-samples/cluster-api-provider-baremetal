Package resolvconf provides utility code to query and update DNS configuration in /etc/resolv.conf
