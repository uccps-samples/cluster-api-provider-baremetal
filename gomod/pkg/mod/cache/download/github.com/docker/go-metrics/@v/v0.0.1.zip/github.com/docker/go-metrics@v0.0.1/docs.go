// This package is small wrapper around the prometheus go client to help enforce convention and best practices for metrics collection in Docker projects.

package metrics
