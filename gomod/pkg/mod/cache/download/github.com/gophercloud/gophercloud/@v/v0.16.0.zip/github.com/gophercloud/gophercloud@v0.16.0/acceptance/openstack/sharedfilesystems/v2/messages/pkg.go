// The v2 package contains acceptance tests for the Openstack Manila V2 messages package

package messages
