[![Gitter chat](http://img.shields.io/badge/gitter-join%20chat%20%E2%86%92-brightgreen.svg)](https://gitter.im/opentracing/public) [![Build Status](https://travis-ci.org/opentracing/basictracer-go.svg?branch=master)](https://travis-ci.org/opentracing/basictracer-go) [![GoDoc](https://godoc.org/github.com/opentracing/basictracer-go?status.svg)](http://godoc.org/github.com/opentracing/basictracer-go)

# basictracer-go
The Go incarnation of the cross-platform "BasicTracer" reference implementation for OpenTracing.

## Status

In early development: there will be backwards-incompatible changes so _caveat emptor_ for now!
