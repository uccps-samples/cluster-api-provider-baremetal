### This repository is no longer actively maintained.

Development of the packages in this repository has moved to https://github.com/gonum/gonum.
Please send pull requests [there](https://github.com/gonum/gonum/pulls) after having checked that your addition has not already been made.
