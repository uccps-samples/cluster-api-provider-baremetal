This package is for internal use only. It is intended to only have
temporary changes before they are upstreamed to golang.org/x/sys/
(a.k.a. https://github.com/golang/sys).
