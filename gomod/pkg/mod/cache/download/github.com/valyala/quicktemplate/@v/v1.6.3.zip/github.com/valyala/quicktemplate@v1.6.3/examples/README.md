[quicktemplate](https://github.com/valyala/quicktemplate) examples:

* [basic usage](https://github.com/valyala/quicktemplate/tree/master/examples/basicserver)
