An example demonstrating basic usage of [quicktemplate](https://github.com/valyala/quicktemplate)
as template engine and [fasthttp](https://github.com/valyala/fasthttp) as http server.

Just run `make` to see the example in action.
Run `make generate run` after modifying [template files](https://github.com/valyala/quicktemplate/tree/master/examples/basicserver/templates).
