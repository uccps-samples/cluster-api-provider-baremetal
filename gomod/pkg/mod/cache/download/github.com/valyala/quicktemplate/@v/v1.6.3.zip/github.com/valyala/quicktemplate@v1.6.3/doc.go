/*
Package quicktemplate provides fast and powerful template engine.

See https://github.com/valyala/quicktemplate for details.
*/
package quicktemplate
